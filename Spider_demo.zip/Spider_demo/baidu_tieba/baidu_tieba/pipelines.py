# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import re

import MySQLdb
import MySQLdb.cursors
import scrapy
from scrapy.contrib import spiderstate
from scrapy.contrib.pipeline.images import ImagesPipeline
from scrapy.exceptions import DropItem
from twisted.enterprise import adbapi


class BaiduTiebaPipeline(object):
    def process_item(self, item, spider):
        return item
        
class MyImagesPipeline(ImagesPipeline):

    
    def file_path(self, request, response=None, info=None):
        image_name_pa = re.compile('(.*?(\.png|\.jpg))')
        url = request.url
        image_guid = url.split('/')[-1]
        image_guid = re.findall(image_name_pa,image_guid)[0]
        return 'full_/%s' % (image_guid) 

    def thumb_path(self, request, thumb_id, response=None, info=None):
        image_name_pa = re.compile('(.*?(\.png|\.jpg))')
        url = request.url
        image_guid = url.split('/')[-1]
        image_guid = re.findall(image_name_pa,image_guid)[0]
        return 'thumbs_/%s/%s' % (thumb_id,image_guid)
               
    
    def get_media_requests(self, item, info):
        for image_url in item['image_urls']:
            yield scrapy.Request(image_url)

    def item_completed(self, results, item, info):
        image_paths = [x['path'] for ok, x in results if ok]
        if not image_paths:
            raise DropItem("Item contains no images")
        item['image_paths'] = image_paths
        return item     

class Mysql_scrapy_pipeline(object):
    def __init__(self):
        self.dbpool = adbapi.ConnectionPool(
                                    dbapiName='MySQLdb',
                                    host='localhost',
                                    db='yq',
                                    user='root',
                                    passwd='minus',
                                    cursorclass= MySQLdb.cursors.DictCursor,
                                    charset = 'utf8',
                                    use_unicode = False
                                    )
        
    def process_item(self,item,spider):
        query = self.dbpool.runInteraction(self._conditional_insert,item)
        return item    
        
    def _conditional_insert(self,tx,item):  
        sql = 'insert into post (id , url, board, site_id, data_type , title , content, post_time, scratch_time , poster_name,poster_id,poster_url,poster_pic_url, comment_num,language_type) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE post_time=%s  '
        param = (item['topic_url'], item['topic_url'], item['topic_board'], item['site_id'],item['data_type'],item['topic_title'], item['topic_content'], item['topic_post_time'],item['scratch_time'], item['topic_author'],item['poster_id'] ,item['homepage'],item['poster_image'],item['topic_reply'],0,item['topic_post_time'])
        tx.execute(sql,param)    
            
            
            