import os
CURRENT_PATH=os.path.dirname(__file__).replace('\\','/')
os.chdir(CURRENT_PATH)
os.system('scrapy crawl dmoz')